﻿using System;
using System.Xml;
/* Victor Kenana */

namespace Assignment1
{
    class Program
    {
        static string ReverseString(string inputString)
        {
            string reversedString = string.Empty;

            for (int counter = inputString.Length - 1; counter >= 0; counter--)
            {
                reversedString = reversedString + inputString[counter];
            }
            return reversedString; 
        }

        static bool IsPalindrome(string inputString)
        {
            string reversedString = ReverseString(inputString);

            if (inputString == reversedString)
                return true;
            else
                return false;
        }

        static void Main(string[] args)
        {
            string stringToReverse = "racecar";

            string stringToDisplay = ReverseString(stringToReverse);
            Console.WriteLine(stringToDisplay);

            bool palidrome = IsPalindrome(stringToReverse);

            if (palidrome)
                Console.WriteLine(stringToReverse + "is a Palidrome");
            else
                Console.WriteLine(stringToReverse + "is not a Palidrome");
            Console.WriteLine(stringToDisplay);

        }
    }
}
